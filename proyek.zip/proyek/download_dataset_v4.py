"""
Download gambar untuk 2 kelas: kamera dan mouse.

Pasang dulu:  pip install icrawler
Jalankan   :  python download_dataset_v4.py

PENTING:
- Hapus folder 'dataset' lama sebelum menjalankan.
- Periksa hasilnya: hapus gambar berwatermark, kolase, ilustrasi, atau yang bukan
  kamera / mouse. Sisakan sekitar 50 gambar per kelas.
"""
import os
from icrawler.builtin import BingImageCrawler

KELAS = {
    "kamera": [
        "compact digital camera white background front view",
        "compact digital camera white background side view",
        "compact digital camera white background back view screen",
        "pocket camera point and shoot isolated product photo",
        "compact digital camera product photo angle",
        "kamera saku digital latar putih",
    ],
    "mouse": [
        "computer mouse white background top view",
        "computer mouse white background side view",
        "computer mouse isolated product photo",
        "wired computer mouse close up",
        "wireless computer mouse product photo angle",
        "computer mouse bottom view sensor",
    ],
}
PER_KEYWORD = 20

for nama, daftar_kata in KELAS.items():
    folder = os.path.join("dataset", nama)
    os.makedirs(folder, exist_ok=True)
    for kata in daftar_kata:
        crawler = BingImageCrawler(storage={"root_dir": folder}, downloader_threads=4)
        crawler.crawl(
            keyword=kata,
            max_num=PER_KEYWORD,
            filters=dict(type="photo", size="medium"),
            file_idx_offset="auto",
        )
    print(f"[{nama}] total file sekarang: {len(os.listdir(folder))}")

print("Selesai. Buka folder dataset, hapus gambar yang salah, sisakan sekitar 50 per kelas.")
