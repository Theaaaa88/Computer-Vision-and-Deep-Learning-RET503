"""
Training ResNet18 untuk 2 kelas: barcode vs jalan.

Struktur folder yang dibutuhkan (taruh di folder yang sama dengan skrip ini):

dataset/
  barcode/   <- 50 foto barcode (berbagai sudut)
  jalan/     <- 50 foto jalan   (berbagai sudut)

Jalankan:  python train_resnet18.py
Hasil     : model_resnet18.pth, grafik_training.png, confusion_matrix.png, hasil_training.txt
"""
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from torchvision import datasets, models, transforms
import matplotlib.pyplot as plt
import numpy as np

# ---------- Pengaturan ----------
DATA_DIR = "dataset"
EPOCHS = 15
BATCH = 8
LR = 1e-3
SEED = 42
device = "cuda" if torch.cuda.is_available() else "cpu"
print("Device:", device)
torch.manual_seed(SEED)

# ---------- Transformasi ----------
norm = transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
train_tf = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.RandomResizedCrop(224, scale=(0.7, 1.0)),
    transforms.RandomRotation(25),
    transforms.ColorJitter(brightness=0.3, contrast=0.3),
    transforms.ToTensor(), norm,
])
val_tf = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(), norm,
])

# ---------- Dataset (80% train, 20% validasi) ----------
full_train = datasets.ImageFolder(DATA_DIR, transform=train_tf)
full_val = datasets.ImageFolder(DATA_DIR, transform=val_tf)
class_names = full_train.classes
print("Kelas:", class_names, "| total gambar:", len(full_train))

n_train = int(0.8 * len(full_train))
n_val = len(full_train) - n_train
g = torch.Generator().manual_seed(SEED)
idx_train, idx_val = random_split(range(len(full_train)), [n_train, n_val], generator=g)
train_set = torch.utils.data.Subset(full_train, idx_train.indices)
val_set = torch.utils.data.Subset(full_val, idx_val.indices)

train_dl = DataLoader(train_set, batch_size=BATCH, shuffle=True)
val_dl = DataLoader(val_set, batch_size=BATCH)

# ---------- Model ResNet18 (pretrained ImageNet) ----------
model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
model.fc = nn.Linear(model.fc.in_features, 2)  # 2 kelas
model = model.to(device)

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=LR)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=7, gamma=0.1)

# ---------- Training ----------
hist = {"train_loss": [], "val_loss": [], "train_acc": [], "val_acc": []}

def run_epoch(dl, train):
    model.train(train)
    total_loss, correct, n = 0, 0, 0
    with torch.set_grad_enabled(train):
        for x, y in dl:
            x, y = x.to(device), y.to(device)
            out = model(x)
            loss = criterion(out, y)
            if train:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            total_loss += loss.item() * x.size(0)
            correct += (out.argmax(1) == y).sum().item()
            n += x.size(0)
    return total_loss / n, correct / n

for ep in range(1, EPOCHS + 1):
    tl, ta = run_epoch(train_dl, True)
    vl, va = run_epoch(val_dl, False)
    scheduler.step()
    for k, v in zip(hist.keys(), [tl, vl, ta, va]):
        hist[k].append(v)
    print(f"Epoch {ep:02d}/{EPOCHS} | loss {tl:.4f} acc {ta:.3f} | val_loss {vl:.4f} val_acc {va:.3f}")

torch.save({"model": model.state_dict(), "classes": class_names}, "model_resnet18.pth")

# ---------- Grafik loss & akurasi ----------
ep_range = range(1, EPOCHS + 1)
plt.figure(figsize=(11, 4))
plt.subplot(1, 2, 1)
plt.plot(ep_range, hist["train_loss"], label="Train")
plt.plot(ep_range, hist["val_loss"], label="Validasi")
plt.title("Loss"); plt.xlabel("Epoch"); plt.legend(); plt.grid(alpha=.3)
plt.subplot(1, 2, 2)
plt.plot(ep_range, hist["train_acc"], label="Train")
plt.plot(ep_range, hist["val_acc"], label="Validasi")
plt.title("Akurasi"); plt.xlabel("Epoch"); plt.legend(); plt.grid(alpha=.3)
plt.tight_layout()
plt.savefig("grafik_training.png", dpi=150)

# ---------- Confusion matrix ----------
model.eval()
cm = np.zeros((2, 2), dtype=int)
with torch.no_grad():
    for x, y in val_dl:
        pred = model(x.to(device)).argmax(1).cpu()
        for t, p in zip(y, pred):
            cm[t][p] += 1

plt.figure(figsize=(4.5, 4))
plt.imshow(cm, cmap="Blues")
plt.xticks([0, 1], class_names); plt.yticks([0, 1], class_names)
plt.xlabel("Prediksi"); plt.ylabel("Sebenarnya"); plt.title("Confusion Matrix")
for i in range(2):
    for j in range(2):
        plt.text(j, i, cm[i, j], ha="center", va="center",
                 color="white" if cm[i, j] > cm.max() / 2 else "black")
plt.tight_layout()
plt.savefig("confusion_matrix.png", dpi=150)

with open("hasil_training.txt", "w") as f:
    f.write(f"Kelas: {class_names}\n")
    f.write(f"Train: {n_train} gambar | Validasi: {n_val} gambar\n")
    f.write(f"Akurasi train akhir : {hist['train_acc'][-1]:.3f}\n")
    f.write(f"Akurasi validasi akhir: {hist['val_acc'][-1]:.3f}\n")
    f.write(f"Confusion matrix:\n{cm}\n")
print("Selesai. Lihat grafik_training.png dan confusion_matrix.png")
